A company requires all of its employees to be linked to certain tech tribes. In the file `users.ts` you'll find an array of all the company users,
and another array of users that have already been linked to tribes. Please write a function that takes both arrays as arguments and returns an array of
all the unlinked users.

** Important **

- Fork this repo before you do anything
- Make all the commits in your forked repo
- Submit link to your forked repo that has all the code.

** Solved **

- make sure you have node.js installed and you can run node command from terminal
- run node linked.js
